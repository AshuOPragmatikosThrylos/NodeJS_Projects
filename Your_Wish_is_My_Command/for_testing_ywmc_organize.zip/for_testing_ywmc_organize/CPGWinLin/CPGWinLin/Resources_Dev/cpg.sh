#!/bin/bash
java -Xdock:name="CPG" -Xmx800m -XX:MaxPermSize=128M -jar CPG.jar