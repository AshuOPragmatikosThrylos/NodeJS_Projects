READ ME
How to create a release. Last updated 3 Aug 2014 by HIF

Developer Release 1.6.2 Aug15 2014 
on Mac Mavericks 10.9.4
Developer Release 0.0.9.4.2 Feb25 2011
Tested on 
Mac SnowLeopard (and Server), Lion,
Windows 7, 2008, Windows Server 2003
Ubuntu, Solaris 11g and RedHat Linux RHEL5

How to prepare CPG Mac application
-----------------------------------

1. Create runnable jar file:
Eclipse (Indigo release Build id: 20110615-0604): 
File > Export > Runnable Java JAR file, put all libraries into the package (Package all libraries into generated JAR), 
and choose output location.
Only source files required.

Jar Bundler (make a link into XCode Developer/Applications/Utilities)
lime:~ lime$ locate JarBundler
/usr/share/java/Tools/Jar Bundler.app/Contents/Resources/JarBundler.icns

Jar Bundler set up: (see below for no JarBundler)

Use the following VM args to improve performance:
-Xmx2G -XX:MaxPermSize=256M 
Use Mac toolbar.
Signature imogenart, Identifier CPG.
Note version as in About box.

When the package is created two folders are required for the program to run:
1. Copy and paste in your secret items in folder .cpg:
lime:CoulsonPlotGenerator lime$ cp -r .cpg CPG.app/Contents/Resources/Java/

Note that .cpg contains the editable readme with the latest instructions and disclaimer etc, and icons for the play/pause show options button, serialized files saving location etc between sessions.

2. Copy and paste in your README_CPG as the program won't open without it:
lime:CoulsonPlotGenerator lime$ cp -r Resources CPG.app/Contents/Resources/Java/Resources

Resources is a folder containing README_CPG: a second copy is supplied as a read me with the program but this is also contained within the help tab of the program.

NO JAR BUNDLER (2014):
In a copy of the previous app Mac bundle
1. copy out the CPG.jar and 
2. edit the .plist file for version number 
3. Change README_CPG 
	a. in CPG, 
	b. CPG.app/Contents/Resources/Java/Resources,

Make a Disc Image (dmg) (see package maker directory, and dmg directories)
Use IconComposer (CPGicon_artwork/Usethese) - search in Spotlight

Other apps (WinLin)
-------------------
From Eclipse create a Runnable Jar file, so that you can double click to open the app.
Place the folders 
.cpg and
Resources 
next to the jar file.
In a copy of the last version:
1. copy out the CPG.jar
2. Change README_CPG in 
	a. WinLin, 
	b. WinLin/Resources (latter is for the program)

This is the same jar file for Mac, Linux, Windows.


