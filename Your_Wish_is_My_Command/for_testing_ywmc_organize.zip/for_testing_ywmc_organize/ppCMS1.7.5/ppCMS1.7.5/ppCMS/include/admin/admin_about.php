<?php
defined('is_running') or die('Not an entry point...');

class admin_about{
	
	function admin_about(){
		global $gpversion;

		echo '<div style="width:600px;padding:0 20px;">';
		echo '<h2>ppCMS  Version '.$gpversion.'</h2>';
		echo '<p>';
		echo 'Free, Open Source and easy to use.';
		echo '</p>';
		echo '<p>';
		echo ' ppCMS is licensed under version 2 of the <a href="http://www.gnu.org/licenses/gpl-2.0.html">GNU General Public License</a>. ';
		echo '</p>';
		
		
		echo '<h2>Thanks For Using ppCMS</h2>';
		echo '<p>';
		echo 'Thanks for using ppCMS . We\'ve worked very hard to find a balance between the ease of use and functionality in Content Management Systems and we think we\'ve done a pretty good job. ';
		echo ' You may agree or disagree though, and the only way for us to know is to hear from you. ';
		echo ' We want to know what you think. Here\'s how:';
		echo '</p>';
		
		echo '<b>Does ppCMS Work?</b>';
		echo '<p>Obviously the first step is to get ppCMS working correctly.';
		echo ' If it\'s not working for you and you think it\'s because of a bug, you can <a href="http://code.google.com/p/ppCMS/issues/list">report it</a> and we\'ll work on fixing it.';
		echo '</p>';
		
		echo '<b>Does ppCMS Work Well?</b>';
		echo '<p>This one is a bit more subjective, but just as important.';
		echo ' There are multiple ways to give us feedback. The following services allow you to rate and comment on ppCMS. ';
		echo '</p>';
		echo '<ul>';
		echo '<li><a href="https://launchpad.net/~aktifbox-studio">LaunchPad.Net</a></li>';
		echo '<li><a href="http://www.aktifbox.com/">AktifBoxStudio</a></li>';
		echo '<li><a href="https://www.interaktifidiots.co.nr/">InterAktifIdiots.Net</a></li>';
		echo '</ul>';
		
		echo '<h3>Credits</h3>';
		echo '<p>';
		echo 'ppCMS is made possible by the open source project hosted at <a href="https://code.google.com/p/ppCMS">GoogleCode.</a> and the many successful GPL projects we\'ve taken inspiration from. ';
		echo '</p>';
		echo '<p>';
		echo 'The <a href="http://www.gnu.org/licenses/gpl-2.0.html">GPL</a> from the Free Software Foundation is the license that the ppCMS software is under.';
		echo '</p>';
		echo '</div>';
		
	}
	
}


